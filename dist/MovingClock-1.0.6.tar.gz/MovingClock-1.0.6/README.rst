MovingClock
===========


**This is a package which can make a MovingClock**


How to use:
import MovingClock
MovingClock.main()


Install Requires:
1.zhdate
2.datetime


*Author:Jason4zh*
*email:13640817984@163.com*
*Made In China*